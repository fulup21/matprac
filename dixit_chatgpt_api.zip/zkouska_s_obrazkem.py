from sk import mujklic
import openai
import json
from typing import Any

openai.api_key=mujklic

def ziskat_base64_pro_klic(soubor_json: str, klic: int) -> Any:
    # Otevru json soubor
    with open(soubor_json, "r", encoding="utf-8") as f:
        obrazky = json.load(f)
    
    for obrazek in obrazky:
            return obrazek["base64"]
    

# ziskas ty base64 data
base64_data = ziskat_base64_pro_klic("obrazky.json", 20)



response = openai.chat.completions.create(
  model="gpt-4o-mini",
  messages=[
    {
      "role": "user",
      "content": [
        {"type": "text", "text": "Co je na tomto obrázku?"},
        {
          "type": "image_url",
          "image_url": {
            "url": f"data:image/jpeg;base64,{base64_data}",
          },
        },
      ],
    }
  ],
  max_tokens=300,
)


print(response.choices[0].message.content)